package com.iamrakeshpanchal.nimusms.workers

import android.content.Context
import android.util.Log
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.api.client.googleapis.extensions.android.gms.auth.GoogleAccountCredential
import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport
import com.google.api.client.json.gson.GsonFactory
import com.google.api.services.drive.Drive
import com.google.api.services.drive.DriveScopes
import com.iamrakeshpanchal.nimusms.NimuSMSApplication
import com.iamrakeshpanchal.nimusms.data.entities.SmsEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayInputStream
import java.io.OutputStreamWriter
import java.text.SimpleDateFormat
import java.util.*

class BackupWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {
    
    companion object {
        private const val TAG = "BackupWorker"
        private const val BACKUP_FOLDER_NAME = "Nimu_SMS_Backups"
        private const val DATE_FORMAT = "yyyyMMdd_HHmmss"
    }
    
    override suspend fun doWork(): Result {
        return try {
            withContext(Dispatchers.IO) {
                val database = NimuSMSApplication.database
                val smsDao = database.smsDao()
                
                // Get all messages for backup
                val messages = smsDao.getAllMessages()
                var messagesList: List<SmsEntity> = emptyList()
                
                // Collect the Flow
                messages.collect { messagesList = it }
                
                if (messagesList.isEmpty()) {
                    Log.d(TAG, "No messages to backup")
                    return@withContext Result.success()
                }
                
                // Create backup file content
                val backupContent = createBackupContent(messagesList)
                
                // Upload to Google Drive
                val success = uploadToGoogleDrive(backupContent)
                
                if (success) {
                    Log.d(TAG, "Backup completed successfully")
                    Result.success()
                } else {
                    Log.e(TAG, "Backup failed")
                    Result.retry()
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Backup error: ${e.message}", e)
            Result.failure()
        }
    }
    
    private fun createBackupContent(messages: List<SmsEntity>): String {
        val jsonBuilder = StringBuilder()
        jsonBuilder.append("{\n")
        jsonBuilder.append("  \"backup_date\": \"${System.currentTimeMillis()}\",\n")
        jsonBuilder.append("  \"message_count\": ${messages.size},\n")
        jsonBuilder.append("  \"messages\": [\n")
        
        messages.forEachIndexed { index, message ->
            jsonBuilder.append("    {\n")
            jsonBuilder.append("      \"id\": ${message.id},\n")
            jsonBuilder.append("      \"thread_id\": ${message.threadId},\n")
            jsonBuilder.append("      \"address\": \"${escapeJson(message.address)}\",\n")
            jsonBuilder.append("      \"body\": \"${escapeJson(message.body)}\",\n")
            jsonBuilder.append("      \"date\": ${message.date},\n")
            jsonBuilder.append("      \"type\": ${message.type},\n")
            jsonBuilder.append("      \"is_otp\": ${message.isOtp},\n")
            jsonBuilder.append("      \"is_promotional\": ${message.isPromotional},\n")
            jsonBuilder.append("      \"needs_action\": ${message.needsAction}\n")
            jsonBuilder.append("    }")
            
            if (index < messages.size - 1) {
                jsonBuilder.append(",")
            }
            jsonBuilder.append("\n")
        }
        
        jsonBuilder.append("  ]\n")
        jsonBuilder.append("}")
        
        return jsonBuilder.toString()
    }
    
    private fun escapeJson(text: String): String {
        return text
            .replace("\\", "\\\\")
            .replace("\"", "\\\"")
            .replace("\n", "\\n")
            .replace("\r", "\\r")
            .replace("\t", "\\t")
    }
    
    private suspend fun uploadToGoogleDrive(content: String): Boolean {
        return try {
            val account = getGoogleAccount()
            if (account == null) {
                Log.e(TAG, "No Google account found")
                return false
            }
            
            val credential = GoogleAccountCredential.usingOAuth2(
                applicationContext,
                listOf(DriveScopes.DRIVE_FILE)
            )
            credential.selectedAccount = account.account
            
            val driveService = Drive.Builder(
                GoogleNetHttpTransport.newTrustedTransport(),
                GsonFactory.getDefaultInstance(),
                credential
            ).setApplicationName("Nimu SMS").build()
            
            // Create or get backup folder
            val folderId = getOrCreateBackupFolder(driveService)
            
            // Create backup file
            val dateFormat = SimpleDateFormat(DATE_FORMAT, Locale.getDefault())
            val fileName = "nimu_sms_backup_${dateFormat.format(Date())}.json"
            
            val fileMetadata = com.google.api.services.drive.model.File().apply {
                name = fileName
                parents = listOf(folderId)
                mimeType = "application/json"
            }
            
            val mediaContent = com.google.api.client.http.ByteArrayContent(
                "application/json",
                content.toByteArray()
            )
            
            driveService.files().create(fileMetadata, mediaContent)
                .setFields("id")
                .execute()
            
            Log.d(TAG, "File uploaded: $fileName")
            true
        } catch (e: Exception) {
            Log.e(TAG, "Google Drive upload error: ${e.message}", e)
            false
        }
    }
    
    private fun getGoogleAccount(): GoogleSignInAccount? {
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestEmail()
            .requestScopes(com.google.android.gms.common.api.Scope(DriveScopes.DRIVE_FILE))
            .build()
        
        val googleSignInClient = GoogleSignIn.getClient(applicationContext, gso)
        return GoogleSignIn.getLastSignedInAccount(applicationContext)
    }
    
    private fun getOrCreateBackupFolder(driveService: Drive): String {
        val folderQuery = "name='$BACKUP_FOLDER_NAME' and mimeType='application/vnd.google-apps.folder' and trashed=false"
        
        val result = driveService.files().list()
            .setQ(folderQuery)
            .setSpaces("drive")
            .setFields("files(id, name)")
            .execute()
        
        val folders = result.files
        if (folders.isNotEmpty()) {
            return folders[0].id
        }
        
        // Create new folder
        val folderMetadata = com.google.api.services.drive.model.File().apply {
            name = BACKUP_FOLDER_NAME
            mimeType = "application/vnd.google-apps.folder"
        }
        
        val folder = driveService.files().create(folderMetadata)
            .setFields("id")
            .execute()
        
        return folder.id
    }
}
