package com.iamrakeshpanchal.nimusms

import android.app.Application
import androidx.appcompat.app.AppCompatDelegate

class NimuSMSApplication : Application() {
    
    override fun onCreate() {
        super.onCreate()
        
        // Enable DayNight theme for dark mode support
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
    }
}
