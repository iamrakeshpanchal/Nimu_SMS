package com.iamrakeshpanchal.nimusms.ui

import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SearchView
import com.iamrakeshpanchal.nimusms.R
import com.iamrakeshpanchal.nimusms.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    
    private lateinit var binding: ActivityMainBinding
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        // Setup toolbar
        setSupportActionBar(binding.toolbar)
        
        // Setup bottom navigation
        setupBottomNavigation()
    }
    
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        
        // Setup search view
        val searchItem = menu.findItem(R.id.action_search)
        val searchView = searchItem.actionView as SearchView
        searchView.queryHint = getString(R.string.hint_search_messages)
        
        return true
    }
    
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_new_message -> {
                // TODO: Open new message dialog
                true
            }
            R.id.action_filter -> {
                // TODO: Open filter dialog
                true
            }
            R.id.action_settings -> {
                // TODO: Open settings
                true
            }
            R.id.action_backup -> {
                // TODO: Trigger backup
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
    
    private fun setupBottomNavigation() {
        binding.bottomNavigationView.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.navigation_all -> {
                    // TODO: Show all messages
                    true
                }
                R.id.navigation_promotional -> {
                    // TODO: Show promotional messages
                    true
                }
                R.id.navigation_otp -> {
                    // TODO: Show OTP messages
                    true
                }
                R.id.navigation_actionable -> {
                    // TODO: Show actionable messages
                    true
                }
                else -> false
            }
        }
    }
}
