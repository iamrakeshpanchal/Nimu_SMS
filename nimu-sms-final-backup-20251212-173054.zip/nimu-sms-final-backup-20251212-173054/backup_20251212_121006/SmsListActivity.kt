package com.iamrakeshpanchal.nimusms

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Intent
import android.database.Cursor
import android.os.Bundle
import android.provider.Telephony
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.*

class SmsListActivity : AppCompatActivity() {
    
    private lateinit var listView: ListView
    private lateinit var emptyText: TextView
    
    private val smsList = ArrayList<SmsItem>()
    private lateinit var adapter: SmsAdapter
    
    data class SmsItem(
        val id: String,
        val address: String,
        val body: String,
        val date: Long,
        val type: Int,
        val read: Boolean
    )
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Create UI programmatically
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 16, 16, 16)
        }
        
        // Title at TOP
        val title = TextView(this).apply {
            text = "📨 SMS Messages"
            textSize = 20f
            setPadding(0, 0, 0, 20)
        }
        layout.addView(title)
        
        // ListView for SMS
        listView = ListView(this)
        layout.addView(listView, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            0,
            1.0f
        ))
        
        // Empty text
        emptyText = TextView(this).apply {
            text = "Loading SMS..."
            gravity = android.view.Gravity.CENTER
            textSize = 16f
        }
        layout.addView(emptyText)
        
        // Settings button at BOTTOM (replacing "Back")
        val settingsBtn = Button(this).apply {
            text = "⚙️ Settings"
            setTextColor(0xFF000000.toInt())
            setOnClickListener {
                finish() // Go back to main screen
            }
        }
        layout.addView(settingsBtn)
        
        setContentView(layout)
        
        // Setup adapter
        adapter = SmsAdapter(this, smsList)
        listView.adapter = adapter
        
        // Click to open SMS detail - FIXED
        listView.onItemClickListener = AdapterView.OnItemClickListener { parent, view, position, id ->
            val sms = smsList[position]
            openSmsDetail(sms)
        }
        
        // Load SMS
        loadSMS()
    }
    
    @SuppressLint("Range")
    private fun loadSMS() {
        emptyText.text = "Loading SMS..."
        
        Thread {
            try {
                val cursor: Cursor? = contentResolver.query(
                    Telephony.Sms.CONTENT_URI,
                    arrayOf(
                        Telephony.Sms._ID,
                        Telephony.Sms.ADDRESS,
                        Telephony.Sms.BODY,
                        Telephony.Sms.DATE,
                        Telephony.Sms.TYPE,
                        Telephony.Sms.READ
                    ),
                    null, null, "${Telephony.Sms.DATE} DESC LIMIT 100"
                )
                
                cursor?.use {
                    while (it.moveToNext()) {
                        val id = it.getString(it.getColumnIndex(Telephony.Sms._ID))
                        val address = it.getString(it.getColumnIndex(Telephony.Sms.ADDRESS)) ?: "Unknown"
                        val body = it.getString(it.getColumnIndex(Telephony.Sms.BODY)) ?: ""
                        val date = it.getLong(it.getColumnIndex(Telephony.Sms.DATE))
                        val type = it.getInt(it.getColumnIndex(Telephony.Sms.TYPE))
                        val read = it.getInt(it.getColumnIndex(Telephony.Sms.READ)) == 1
                        
                        smsList.add(SmsItem(id, address, body, date, type, read))
                    }
                }
                
                runOnUiThread {
                    adapter.notifyDataSetChanged()
                    if (smsList.isEmpty()) {
                        emptyText.text = "No SMS messages found"
                    } else {
                        emptyText.text = ""
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    emptyText.text = "Error: ${e.message}"
                }
            }
        }.start()
    }
    
    private fun openSmsDetail(sms: SmsItem) {
        // Mark as read
        markAsRead(sms.id)
        
        // Open detail activity
        val intent = Intent(this, SmsDetailActivity::class.java).apply {
            putExtra("sms_id", sms.id)
            putExtra("address", sms.address)
            putExtra("body", sms.body)
            putExtra("date", sms.date)
            putExtra("type", sms.type)
        }
        startActivity(intent)
    }
    
    private fun markAsRead(smsId: String) {
        try {
            val values = ContentValues().apply { put(Telephony.Sms.READ, 1) }
            contentResolver.update(
                Telephony.Sms.CONTENT_URI,
                values,
                "${Telephony.Sms._ID} = ?",
                arrayOf(smsId)
            )
        } catch (e: Exception) {
            // Ignore
        }
    }
    
    private fun deleteSMS(position: Int) {
        val sms = smsList[position]
        AlertDialog.Builder(this)
            .setTitle("Delete Message")
            .setMessage("Delete message from ${sms.address}?")
            .setPositiveButton("🗑️ Delete") { _, _ ->
                try {
                    contentResolver.delete(
                        Telephony.Sms.CONTENT_URI,
                        "${Telephony.Sms._ID} = ?",
                        arrayOf(sms.id)
                    )
                    smsList.removeAt(position)
                    adapter.notifyDataSetChanged()
                    Toast.makeText(this, "Message deleted", Toast.LENGTH_SHORT).show()
                    
                    if (smsList.isEmpty()) {
                        emptyText.text = "No SMS messages"
                    }
                } catch (e: Exception) {
                    Toast.makeText(this, "Delete failed", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
    
    inner class SmsAdapter(
        private val context: android.content.Context,
        private val items: List<SmsItem>
    ) : ArrayAdapter<SmsItem>(context, android.R.layout.simple_list_item_2, items) {
        
        @SuppressLint("SimpleDateFormat")
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val view = convertView ?: LayoutInflater.from(context)
                .inflate(android.R.layout.simple_list_item_2, parent, false)
            
            val sms = items[position]
            val text1 = view.findViewById<TextView>(android.R.id.text1)
            val text2 = view.findViewById<TextView>(android.R.id.text2)
            
            val typeIcon = when(sms.type) {
                Telephony.Sms.MESSAGE_TYPE_INBOX -> "📥 "
                Telephony.Sms.MESSAGE_TYPE_SENT -> "📤 "
                else -> "📱 "
            }
            
            text1.text = "$typeIcon${sms.address}"
            text2.text = "${sms.body.take(80)}...\n${SimpleDateFormat("MMM dd, HH:mm").format(Date(sms.date))}"
            
            // Add long press to delete
            view.setOnLongClickListener {
                deleteSMS(position)
                true
            }
            
            return view
        }
    }
}
