package com.iamrakeshpanchal.nimusms.workers

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.iamrakeshpanchal.nimusms.NimuSMSApplication
import com.iamrakeshpanchal.nimusms.viewmodels.SmsViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class SmsProcessingWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {
    
    override suspend fun doWork(): Result {
        return try {
            val address = inputData.getString("address") ?: return Result.failure()
            val body = inputData.getString("body") ?: return Result.failure()
            val timestamp = inputData.getLong("timestamp", System.currentTimeMillis())
            
            withContext(Dispatchers.IO) {
                // Process SMS in background
                val database = NimuSMSApplication.database
                val viewModel = SmsViewModel(database)
                
                viewModel.processIncomingSms(address, body, timestamp)
            }
            
            Result.success()
        } catch (e: Exception) {
            Result.failure()
        }
    }
}
