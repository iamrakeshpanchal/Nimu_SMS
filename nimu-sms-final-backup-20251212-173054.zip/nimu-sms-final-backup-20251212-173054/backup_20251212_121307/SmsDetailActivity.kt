package com.iamrakeshpanchal.nimusms

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Telephony
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.*

class SmsDetailActivity : AppCompatActivity() {
    
    private lateinit var smsId: String
    private lateinit var phoneNumber: String
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Get SMS data
        smsId = intent.getStringExtra("sms_id") ?: ""
        phoneNumber = intent.getStringExtra("address") ?: ""
        val body = intent.getStringExtra("body") ?: ""
        val date = intent.getLongExtra("date", System.currentTimeMillis())
        
        // Create UI programmatically
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 20, 20, 20)
        }
        
        // Address at TOP
        val addressText = TextView(this).apply {
            text = "From: $phoneNumber"
            textSize = 22f
            setPadding(0, 0, 0, 10)
        }
        layout.addView(addressText)
        
        // Date
        val dateText = TextView(this).apply {
            text = "Date: ${SimpleDateFormat("EEE, MMM dd yyyy HH:mm:ss").format(Date(date))}"
            textSize = 14f
            setTextColor(android.graphics.Color.GRAY)
            setPadding(0, 0, 0, 20)
        }
        layout.addView(dateText)
        
        // Body
        val bodyText = TextView(this).apply {
            text = body
            textSize = 18f
            setLineSpacing(1.2f, 1.2f)
            setPadding(0, 0, 0, 40)
        }
        layout.addView(bodyText)
        
        // Action buttons
        val buttonLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        
        val replyBtn = Button(this).apply {
            text = "📝 Reply"
            setOnClickListener { replyToSMS() }
        }
        buttonLayout.addView(replyBtn)
        
        val callBtn = Button(this).apply {
            text = "📞 Call"
            setOnClickListener { callNumber() }
        }
        buttonLayout.addView(callBtn)
        
        val deleteBtn = Button(this).apply {
            text = "🗑️ Delete"
            setOnClickListener { deleteSMS() }
        }
        buttonLayout.addView(deleteBtn)
        
        layout.addView(buttonLayout)
        
        // Settings button at BOTTOM
        val settingsBtn = Button(this).apply {
            text = "⚙️ Settings"
            setTextColor(0xFF000000.toInt())
            setOnClickListener { finish() } // Go back
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = 40 }
        }
        layout.addView(settingsBtn)
        
        val scrollView = ScrollView(this)
        scrollView.addView(layout)
        setContentView(scrollView)
    }
    
    private fun replyToSMS() {
        val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$phoneNumber"))
        intent.putExtra("sms_body", "")
        startActivity(intent)
    }
    
    private fun callNumber() {
        val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phoneNumber"))
        startActivity(intent)
    }
    
    private fun deleteSMS() {
        AlertDialog.Builder(this)
            .setTitle("Delete Message")
            .setMessage("Delete this message from $phoneNumber?")
            .setPositiveButton("🗑️ Delete") { _, _ ->
                try {
                    contentResolver.delete(
                        Telephony.Sms.CONTENT_URI,
                        "${Telephony.Sms._ID} = ?",
                        arrayOf(smsId)
                    )
                    Toast.makeText(this, "Message deleted", Toast.LENGTH_SHORT).show()
                    finish()
                } catch (e: Exception) {
                    Toast.makeText(this, "Delete failed", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
