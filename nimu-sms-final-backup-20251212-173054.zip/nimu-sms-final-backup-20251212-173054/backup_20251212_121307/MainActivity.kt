package com.iamrakeshpanchal.nimusms

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Create UI programmatically
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(30, 30, 30, 30)
        }
        
        // Title at TOP
        val title = TextView(this).apply {
            text = "📱 Nimu SMS"
            textSize = 24f
        }
        layout.addView(title)
        
        // Status
        val status = TextView(this).apply {
            text = "Ready to load SMS messages"
            textSize = 16f
            setPadding(0, 20, 0, 40)
        }
        layout.addView(status)
        
        // Load SMS Button
        val loadBtn = Button(this).apply {
            text = "📨 Load SMS Messages"
            setOnClickListener {
                checkPermissions()
            }
        }
        layout.addView(loadBtn)
        
        // Send SMS Button
        val sendBtn = Button(this).apply {
            text = "✉️ Send SMS"
            setOnClickListener {
                Toast.makeText(this@MainActivity, "Send SMS feature", Toast.LENGTH_SHORT).show()
            }
        }
        layout.addView(sendBtn)
        
        // Settings button at BOTTOM
        val settingsBtn = Button(this).apply {
            text = "⚙️ Settings"
            setTextColor(0xFF000000.toInt())
            setOnClickListener { showSettings() }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = 40 }
        }
        layout.addView(settingsBtn)
        
        setContentView(layout)
        
        // Check permissions on start
        checkPermissions()
    }
    
    private fun checkPermissions() {
        val permissions = arrayOf(
            Manifest.permission.READ_SMS,
            Manifest.permission.SEND_SMS,
            Manifest.permission.READ_CONTACTS
        )
        
        val missingPermissions = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        
        if (missingPermissions.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, missingPermissions.toTypedArray(), 100)
        } else {
            Toast.makeText(this, "Loading SMS...", Toast.LENGTH_SHORT).show()
            // Open SMS list
            openSmsList()
        }
    }
    
    private fun openSmsList() {
        startActivity(Intent(this, SmsListActivity::class.java))
    }
    
    private fun showSettings() {
        AlertDialog.Builder(this)
            .setTitle("⚙️ Settings")
            .setItems(arrayOf("Theme", "Notifications", "Backup", "About")) { _, which ->
                Toast.makeText(this, "Settings option ${which + 1}", Toast.LENGTH_SHORT).show()
            }
            .show()
    }
    
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 100) {
            if (grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) {
                Toast.makeText(this, "Permissions granted!", Toast.LENGTH_SHORT).show()
                openSmsList()
            } else {
                Toast.makeText(this, "Permissions denied!", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
