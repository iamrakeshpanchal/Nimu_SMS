package com.iamrakeshpanchal.nimusms

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.provider.Telephony
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Set dark theme
        setTheme(R.style.AppTheme_Dark)
        
        // Check if intent is to send a message
        if (intent?.action == Intent.ACTION_SENDTO || 
            intent?.action == Intent.ACTION_SEND ||
            intent?.action == Intent.ACTION_VIEW) {
            
            val data = intent.data
            if (data != null && (data.scheme == "sms" || data.scheme == "smsto" || 
                                data.scheme == "mms" || data.scheme == "mmsto")) {
                val composeIntent = Intent(this, ComposeActivity::class.java)
                composeIntent.data = intent.data
                composeIntent.putExtras(intent)
                startActivity(composeIntent)
                finish()
                return
            }
        }
        
        // Directly check permissions and open SMS list
        checkPermissions()
    }
    
    private fun checkPermissions() {
        val permissions = arrayOf(
            Manifest.permission.READ_SMS,
            Manifest.permission.SEND_SMS,
            Manifest.permission.READ_CONTACTS
        )
        
        val missingPermissions = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        
        if (missingPermissions.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, missingPermissions.toTypedArray(), 100)
        } else {
            openSmsList()
        }
    }
    
    private fun openSmsList() {
        startActivity(Intent(this, SmsListActivity::class.java))
        finish() // Remove this activity from back stack
    }
    
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 100) {
            if (grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) {
                openSmsList()
            } else {
                Toast.makeText(this, "Permissions required", Toast.LENGTH_SHORT).show()
                finish()
            }
        }
    }
}
