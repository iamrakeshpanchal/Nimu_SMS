package com.iamrakeshpanchal.nimusms

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Telephony
import android.util.Log
import android.widget.Toast

class SmsReceiver : BroadcastReceiver() {
    
    override fun onReceive(context: Context, intent: Intent) {
        Log.d("NimuSMS", "SMS action: ${intent.action}")
        
        when (intent.action) {
            Telephony.Sms.Intents.SMS_DELIVER_ACTION -> {
                handleIncomingSMS(context, intent)
            }
            "android.provider.Telephony.SMS_RECEIVED" -> {
                // This is for when app is not default but still wants to receive SMS
                if (!isDefaultSmsApp(context)) {
                    Log.d("NimuSMS", "App is not default, but received SMS")
                }
            }
        }
    }
    
    private fun isDefaultSmsApp(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            context.packageName == Telephony.Sms.getDefaultSmsPackage(context)
        } else {
            false
        }
    }
    
    private fun handleIncomingSMS(context: Context, intent: Intent) {
        try {
            val smsMessages = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                Telephony.Sms.Intents.getMessagesFromIntent(intent)
            } else {
                @Suppress("DEPRECATION")
                intent.getSerializableExtra("pdus") as? Array<*> ?: emptyArray()
            }
            
            for (message in smsMessages) {
                if (message is android.telephony.SmsMessage) {
                    val sender = message.displayOriginatingAddress ?: "Unknown"
                    val body = message.displayMessageBody ?: ""
                    
                    Log.d("NimuSMS", "New SMS from $sender: ${body.take(50)}...")
                    Toast.makeText(context, "📨 New SMS from $sender", Toast.LENGTH_SHORT).show()
                    
                    // Here you would typically:
                    // 1. Save to database
                    // 2. Update UI if app is open
                    // 3. Show notification
                }
            }
        } catch (e: Exception) {
            Log.e("NimuSMS", "Error handling SMS: ${e.message}")
        }
    }
}
