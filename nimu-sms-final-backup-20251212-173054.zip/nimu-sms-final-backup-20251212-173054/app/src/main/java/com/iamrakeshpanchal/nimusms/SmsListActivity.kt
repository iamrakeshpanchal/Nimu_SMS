package com.iamrakeshpanchal.nimusms

import android.annotation.SuppressLint
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.database.Cursor
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Telephony
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.viewpager.widget.PagerAdapter
import androidx.viewpager.widget.ViewPager
import java.text.SimpleDateFormat
import java.util.*

class SmsListActivity : AppCompatActivity() {
    
    private lateinit var viewPager: ViewPager
    private lateinit var searchBox: EditText
    private lateinit var smsCountText: TextView
    private lateinit var groupTabs: HorizontalScrollView
    private lateinit var groupTabsContainer: LinearLayout
    
    private val smsList = ArrayList<SmsItem>()
    private val otpList = ArrayList<SmsItem>()
    private val financeList = ArrayList<SmsItem>()
    private val personalList = ArrayList<SmsItem>()
    private val promotionList = ArrayList<SmsItem>()
    private val customGroups = mutableMapOf<String, ArrayList<SmsItem>>()
    private val groupFilters = mutableMapOf<String, String>() // Group -> Filter text
    
    private lateinit var backupManager: BackupManager
    
    // Group colors
    private val groupColors = mutableMapOf(
        "All SMS" to "#4CAF50",
        "OTP" to "#2196F3",
        "Finance" to "#FF9800",
        "Personal" to "#9C27B0",
        "Promotions" to "#F44336"
    )
    
    data class SmsItem(
        val id: String,
        val address: String,
        val body: String,
        val date: Long,
        val type: Int,
        val read: Boolean
    )
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Set dark theme
        setTheme(R.style.AppTheme_Dark)
        
        // Initialize backup manager
        backupManager = BackupManager(this)
        
        // Create UI
        val mainLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(Color.parseColor("#121212"))
        }
        
        // Search bar with icons
        val searchBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setPadding(16, 16, 16, 16)
            }
            setBackgroundColor(Color.parseColor("#1E1E1E"))
        }
        
        // Search icon
        val searchIcon = TextView(this).apply {
            text = "🔍"
            textSize = 20f
            setTextColor(Color.WHITE)
            setPadding(10, 0, 15, 0)
        }
        searchBar.addView(searchIcon)
        
        // Search box
        searchBox = EditText(this).apply {
            hint = "Search messages..."
            setHintTextColor(Color.GRAY)
            textSize = 16f
            setTextColor(Color.WHITE)
            setSingleLine(true)
            setBackgroundColor(Color.parseColor("#2D2D2D"))
            setPadding(20, 15, 20, 15)
            layoutParams = LinearLayout.LayoutParams(
                0,
                LinearLayout.LayoutParams.WRAP_CONTENT,
                1.0f
            )
        }
        searchBar.addView(searchBox)
        
        // Compose button in search bar
        val composeBtn = Button(this).apply {
            text = "✉️"
            textSize = 18f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.TRANSPARENT)
            setPadding(10, 0, 10, 0)
            setOnClickListener {
                val intent = Intent(this@SmsListActivity, ComposeActivity::class.java)
                startActivity(intent)
            }
        }
        searchBar.addView(composeBtn)
        
        // Three-dot menu in search bar
        val menuBtn = Button(this).apply {
            text = "⋮"
            textSize = 22f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.TRANSPARENT)
            setPadding(10, 0, 10, 0)
            setOnClickListener { showThreeDotMenu() }
        }
        searchBar.addView(menuBtn)
        
        mainLayout.addView(searchBar)
        
        // Horizontal scrollable group tabs
        groupTabs = HorizontalScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            setBackgroundColor(Color.parseColor("#1E1E1E"))
        }
        
        groupTabsContainer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(8, 8, 8, 8)
        }
        
        groupTabs.addView(groupTabsContainer)
        mainLayout.addView(groupTabs)
        
        // SMS Count
        smsCountText = TextView(this).apply {
            text = "Messages: 0"
            textSize = 14f
            setTextColor(Color.LTGRAY)
            setPadding(16, 8, 16, 12)
            setBackgroundColor(Color.parseColor("#1E1E1E"))
        }
        mainLayout.addView(smsCountText)
        
        // Divider line
        val divider = View(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                1
            )
            setBackgroundColor(Color.parseColor("#333333"))
        }
        mainLayout.addView(divider)
        
        // ViewPager for swipeable groups
        viewPager = ViewPager(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                0,
                1.0f
            )
        }
        mainLayout.addView(viewPager)
        
        setContentView(mainLayout)
        
        // Setup ViewPager
        viewPager.adapter = GroupPagerAdapter()
        viewPager.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {
            override fun onPageSelected(position: Int) {
                updateGroupSelection(position)
                // Scroll to selected tab
                scrollToTab(position)
            }
            override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {}
            override fun onPageScrollStateChanged(state: Int) {}
        })
        
        // Search listener
        searchBox.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                filterSMS()
            }
        })
        
        // Load SMS
        loadAllSMS()
    }
    
    private fun scrollToTab(position: Int) {
        val tabView = groupTabsContainer.getChildAt(position)
        tabView?.let {
            val scrollPos = it.left - (groupTabs.width - it.width) / 2
            groupTabs.smoothScrollTo(scrollPos, 0)
        }
    }
    
    override fun onBackPressed() {
        // Exit app when back is pressed from SMS list
        finishAffinity()
    }
    
    private fun updateGroupSelection(position: Int) {
        val allGroups = getAllGroups()
        
        if (position < allGroups.size) {
            // Update tab colors
            for (i in 0 until groupTabsContainer.childCount) {
                val tab = groupTabsContainer.getChildAt(i) as? Button
                tab?.let {
                    if (i == position) {
                        it.setTextColor(Color.WHITE)
                        it.setBackgroundColor(Color.parseColor(groupColors[allGroups[i]] ?: "#4CAF50"))
                    } else {
                        it.setTextColor(Color.parseColor(groupColors[allGroups[i]] ?: "#4CAF50"))
                        it.setBackgroundColor(Color.TRANSPARENT)
                    }
                }
            }
            
            // Update count
            updateSmsCount()
        }
    }
    
    private fun getAllGroups(): List<String> {
        val groups = mutableListOf("All SMS", "OTP", "Finance", "Personal", "Promotions")
        groups.addAll(customGroups.keys)
        return groups
    }
    
    private fun createGroupTabs() {
        groupTabsContainer.removeAllViews()
        val groups = getAllGroups()
        
        for ((index, group) in groups.withIndex()) {
            // Truncate group name to 8 characters max
            val displayName = if (group.length > 8) group.substring(0, 8) + ".." else group
            
            val tab = Button(this).apply {
                text = displayName
                textSize = 12f
                setPadding(16, 10, 16, 10)
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    setMargins(4, 4, 4, 4)
                }
                setOnClickListener {
                    viewPager.currentItem = index
                }
                
                // Set minimum width for all tabs to be same size
                minimumWidth = 100
            }
            groupTabsContainer.addView(tab)
        }
        
        // Set initial selection
        if (groups.isNotEmpty()) {
            updateGroupSelection(0)
        }
    }
    
    private fun showThreeDotMenu() {
        val menuItems = arrayOf(
            "Backup & Restore",
            "Create New Group",
            "Create Filter",
            "Change Group Colors",
            "Settings",
            "About"
        )
        
        AlertDialog.Builder(this)
            .setTitle("Menu")
            .setItems(menuItems) { dialog, which ->
                when (which) {
                    0 -> showBackupRestoreMenu()
                    1 -> createNewGroup()
                    2 -> createNewFilter()
                    3 -> changeGroupColors()
                    4 -> showSettings()
                    5 -> showAbout()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
    
    private fun showBackupRestoreMenu() {
        AlertDialog.Builder(this)
            .setTitle("Backup & Restore")
            .setItems(arrayOf("Backup SMS", "Restore Backup")) { dialog, which ->
                when (which) {
                    0 -> backupSMS()
                    1 -> restoreBackup()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
    
    private fun createNewGroup() {
        val input = EditText(this)
        input.hint = "Enter group name"
        input.setTextColor(Color.WHITE)
        input.setHintTextColor(Color.GRAY)
        input.setBackgroundColor(Color.parseColor("#2D2D2D"))
        input.setPadding(20, 15, 20, 15)
        
        AlertDialog.Builder(this)
            .setTitle("Create New Group")
            .setView(input)
            .setPositiveButton("Create") { dialog, which ->
                val groupName = input.text.toString().trim()
                if (groupName.isNotEmpty()) {
                    if (!customGroups.containsKey(groupName)) {
                        customGroups[groupName] = ArrayList()
                        groupColors[groupName] = getRandomColor()
                        createGroupTabs()
                        (viewPager.adapter as? GroupPagerAdapter)?.notifyDataSetChanged()
                        Toast.makeText(this, "Group '$groupName' created", Toast.LENGTH_SHORT).show()
                        
                        // Ask if user wants to add a filter for this group
                        askToAddFilter(groupName)
                    } else {
                        Toast.makeText(this, "Group already exists", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
    
    private fun askToAddFilter(groupName: String) {
        AlertDialog.Builder(this)
            .setTitle("Add Filter to Group")
            .setMessage("Do you want to add a filter to automatically sort messages into '$groupName'?")
            .setPositiveButton("Yes") { dialog, which ->
                createFilterForGroup(groupName)
            }
            .setNegativeButton("No", null)
            .show()
    }
    
    private fun createFilterForGroup(groupName: String) {
        val input = EditText(this)
        input.hint = "Filter text (e.g., 'meeting', 'dinner', sender name)"
        input.setTextColor(Color.WHITE)
        input.setHintTextColor(Color.GRAY)
        input.setBackgroundColor(Color.parseColor("#2D2D2D"))
        input.setPadding(20, 15, 20, 15)
        
        AlertDialog.Builder(this)
            .setTitle("Create Filter for '$groupName'")
            .setView(input)
            .setPositiveButton("Create") { dialog, which ->
                val filterText = input.text.toString().trim()
                if (filterText.isNotEmpty()) {
                    groupFilters[groupName] = filterText
                    applyFilterToGroup(groupName, filterText)
                    Toast.makeText(this, "Filter added to '$groupName'", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
    
    private fun createNewFilter() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(10, 10, 10, 10)
        }
        
        // Group selection
        val groups = getAllGroups().filter { it !in listOf("All SMS", "OTP", "Finance", "Personal", "Promotions") }
        val groupSpinner = Spinner(this)
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, 
            listOf("Select Group") + groups + "Create New Group")
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        groupSpinner.adapter = adapter
        
        layout.addView(groupSpinner)
        
        // Filter input
        val filterInput = EditText(this)
        filterInput.hint = "Filter text (e.g., 'meeting', sender name)"
        filterInput.setTextColor(Color.WHITE)
        filterInput.setHintTextColor(Color.GRAY)
        filterInput.setBackgroundColor(Color.parseColor("#2D2D2D"))
        filterInput.setPadding(20, 15, 20, 15)
        layout.addView(filterInput)
        
        AlertDialog.Builder(this)
            .setTitle("Create New Filter")
            .setView(layout)
            .setPositiveButton("Create") { dialog, which ->
                val selectedGroup = groupSpinner.selectedItem.toString()
                val filterText = filterInput.text.toString().trim()
                
                if (selectedGroup == "Create New Group") {
                    // Create new group with filter
                    createNewGroupWithFilter(filterText)
                } else if (selectedGroup != "Select Group" && filterText.isNotEmpty()) {
                    // Add filter to existing group
                    groupFilters[selectedGroup] = filterText
                    applyFilterToGroup(selectedGroup, filterText)
                    Toast.makeText(this, "Filter added to '$selectedGroup'", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
    
    private fun createNewGroupWithFilter(filterText: String) {
        val input = EditText(this)
        input.hint = "Group name for filter: $filterText"
        input.setTextColor(Color.WHITE)
        input.setHintTextColor(Color.GRAY)
        input.setBackgroundColor(Color.parseColor("#2D2D2D"))
        input.setPadding(20, 15, 20, 15)
        
        AlertDialog.Builder(this)
            .setTitle("Create Group for Filter")
            .setView(input)
            .setPositiveButton("Create") { dialog, which ->
                val groupName = input.text.toString().trim()
                if (groupName.isNotEmpty() && filterText.isNotEmpty()) {
                    if (!customGroups.containsKey(groupName)) {
                        customGroups[groupName] = ArrayList()
                        groupColors[groupName] = getRandomColor()
                        groupFilters[groupName] = filterText
                        applyFilterToGroup(groupName, filterText)
                        createGroupTabs()
                        (viewPager.adapter as? GroupPagerAdapter)?.notifyDataSetChanged()
                        Toast.makeText(this, "Group '$groupName' created with filter", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
    
    private fun applyFilterToGroup(groupName: String, filterText: String) {
        val groupList = customGroups[groupName] ?: return
        groupList.clear()
        
        val lowerFilter = filterText.lowercase(Locale.getDefault())
        for (sms in smsList) {
            if (sms.address.lowercase(Locale.getDefault()).contains(lowerFilter) ||
                sms.body.lowercase(Locale.getDefault()).contains(lowerFilter)) {
                groupList.add(sms)
            }
        }
    }
    
    private fun getRandomColor(): String {
        val colors = listOf(
            "#E91E63", "#9C27B0", "#673AB7", "#3F51B5", "#2196F3",
            "#03A9F4", "#00BCD4", "#009688", "#4CAF50", "#8BC34A",
            "#CDDC39", "#FFEB3B", "#FFC107", "#FF9800", "#FF5722"
        )
        return colors.random()
    }
    
    private fun backupSMS() {
        if (backupManager.backupSMS(smsList)) {
            Toast.makeText(this, "Backup created", Toast.LENGTH_SHORT).show()
        }
    }
    
    private fun restoreBackup() {
        val backupFiles = backupManager.getBackupFiles()
        if (backupFiles.isEmpty()) {
            Toast.makeText(this, "No backups found", Toast.LENGTH_SHORT).show()
            return
        }
        
        val fileNames = backupFiles.map { it.name }.toTypedArray()
        
        AlertDialog.Builder(this)
            .setTitle("Select Backup to Restore")
            .setItems(fileNames) { dialog, which ->
                backupManager.restoreBackup(backupFiles[which])
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
    
    private fun changeGroupColors() {
        val groups = getAllGroups()
        val colors = arrayOf("Green", "Blue", "Orange", "Purple", "Red", "Custom...")
        
        AlertDialog.Builder(this)
            .setTitle("Select Group")
            .setItems(groups.toTypedArray()) { dialog, groupIndex ->
                AlertDialog.Builder(this)
                    .setTitle("Color for ${groups[groupIndex]}")
                    .setItems(colors) { dialog2, colorIndex ->
                        val colorHex = when (colorIndex) {
                            0 -> "#4CAF50"
                            1 -> "#2196F3"
                            2 -> "#FF9800"
                            3 -> "#9C27B0"
                            4 -> "#F44336"
                            5 -> {
                                showColorPicker(groups[groupIndex])
                                return@setItems
                            }
                            else -> "#4CAF50"
                        }
                        groupColors[groups[groupIndex]] = colorHex
                        createGroupTabs()
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
    
    private fun showColorPicker(groupName: String) {
        val input = EditText(this)
        input.hint = "#RRGGBB"
        input.setTextColor(Color.WHITE)
        input.setHintTextColor(Color.GRAY)
        input.setBackgroundColor(Color.parseColor("#2D2D2D"))
        input.setPadding(20, 15, 20, 15)
        
        AlertDialog.Builder(this)
            .setTitle("Enter Color for $groupName")
            .setView(input)
            .setPositiveButton("Set") { dialog, which ->
                val color = input.text.toString().trim()
                if (color.matches("#[0-9A-Fa-f]{6}".toRegex())) {
                    groupColors[groupName] = color
                    createGroupTabs()
                } else {
                    Toast.makeText(this, "Invalid color", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
    
    private fun showSettings() {
        AlertDialog.Builder(this)
            .setTitle("Settings")
            .setMessage("Appearance: Dark Theme\nNotifications: On\nPrivacy: Standard")
            .setPositiveButton("OK", null)
            .show()
    }
    
    private fun showAbout() {
        AlertDialog.Builder(this)
            .setTitle("About")
            .setMessage("Nimu SMS v3.0\nSmart SMS Manager with Groups & Filters")
            .setPositiveButton("OK", null)
            .show()
    }
    
    private fun filterSMS() {
        val query = searchBox.text.toString().trim().lowercase(Locale.getDefault())
        
        // Clear all lists
        otpList.clear()
        financeList.clear()
        personalList.clear()
        promotionList.clear()
        customGroups.values.forEach { it.clear() }
        
        for (sms in smsList) {
            if (query.isEmpty() || sms.address.lowercase(Locale.getDefault()).contains(query) ||
                sms.body.lowercase(Locale.getDefault()).contains(query)) {
                
                // Apply standard groups
                when {
                    isOtpSms(sms) -> otpList.add(sms)
                    isFinanceSms(sms) -> financeList.add(sms)
                    isPromotionSms(sms) -> promotionList.add(sms)
                    else -> personalList.add(sms)
                }
                
                // Apply custom filters
                for ((groupName, filterText) in groupFilters) {
                    if (sms.address.lowercase(Locale.getDefault()).contains(filterText.lowercase(Locale.getDefault())) ||
                        sms.body.lowercase(Locale.getDefault()).contains(filterText.lowercase(Locale.getDefault()))) {
                        customGroups[groupName]?.add(sms)
                    }
                }
            }
        }
        
        // Notify adapter
        viewPager.adapter?.notifyDataSetChanged()
        updateSmsCount()
    }
    
    private fun updateSmsCount() {
        val position = viewPager.currentItem
        val groups = getAllGroups()
        
        if (position < groups.size) {
            val groupName = groups[position]
            val count = when (groupName) {
                "All SMS" -> smsList.size
                "OTP" -> otpList.size
                "Finance" -> financeList.size
                "Personal" -> personalList.size
                "Promotions" -> promotionList.size
                else -> customGroups[groupName]?.size ?: 0
            }
            smsCountText.text = "$groupName: $count messages"
        }
    }
    
    private fun isOtpSms(sms: SmsItem): Boolean {
        val body = sms.body.lowercase(Locale.getDefault())
        return body.contains("otp") || body.contains("verification") ||
               "\\d{4,6}".toRegex().containsMatchIn(body)
    }
    
    private fun isFinanceSms(sms: SmsItem): Boolean {
        val body = sms.body.lowercase(Locale.getDefault())
        val financeWords = listOf("bank", "upi", "payment", "transaction", "debit", "credit", "balance", "account")
        return financeWords.any { body.contains(it) }
    }
    
    private fun isPromotionSms(sms: SmsItem): Boolean {
        val body = sms.body.lowercase(Locale.getDefault())
        val promoWords = listOf("offer", "discount", "sale", "deal", "coupon", "shop", "buy", "shop")
        return promoWords.any { body.contains(it) }
    }
    
    @SuppressLint("Range")
    private fun loadAllSMS() {
        Thread {
            try {
                val cursor: Cursor? = contentResolver.query(
                    Telephony.Sms.CONTENT_URI,
                    arrayOf(
                        Telephony.Sms._ID,
                        Telephony.Sms.ADDRESS,
                        Telephony.Sms.BODY,
                        Telephony.Sms.DATE,
                        Telephony.Sms.TYPE,
                        Telephony.Sms.READ
                    ),
                    null, null, "${Telephony.Sms.DATE} DESC"
                )
                
                cursor?.use {
                    smsList.clear()
                    while (it.moveToNext()) {
                        val id = it.getString(it.getColumnIndex(Telephony.Sms._ID))
                        val address = it.getString(it.getColumnIndex(Telephony.Sms.ADDRESS)) ?: "Unknown"
                        val body = it.getString(it.getColumnIndex(Telephony.Sms.BODY)) ?: ""
                        val date = it.getLong(it.getColumnIndex(Telephony.Sms.DATE))
                        val type = it.getInt(it.getColumnIndex(Telephony.Sms.TYPE))
                        val read = it.getInt(it.getColumnIndex(Telephony.Sms.READ)) == 1
                        
                        smsList.add(SmsItem(id, address, body, date, type, read))
                    }
                }
                
                runOnUiThread {
                    createGroupTabs()
                    filterSMS()
                }
            } catch (e: Exception) {
                Log.e("LOAD_ERROR", "Error: ${e.message}")
            }
        }.start()
    }
    
    private fun copyOtpToClipboard(otp: String) {
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText("OTP", otp)
        clipboard.setPrimaryClip(clip)
        Toast.makeText(this, "OTP copied: $otp", Toast.LENGTH_SHORT).show()
    }
    
    private fun extractOtp(text: String): String? {
        val pattern = "\\b\\d{4,6}\\b".toRegex()
        return pattern.find(text)?.value
    }
    
    private fun openSmsDetail(sms: SmsItem) {
        // Auto-copy OTP if present
        if (isOtpSms(sms)) {
            val otp = extractOtp(sms.body)
            otp?.let { copyOtpToClipboard(it) }
        }
        
        // Mark as read
        markAsRead(sms.id)
        
        // Open detail
        val intent = Intent(this, SmsDetailActivity::class.java).apply {
            putExtra("sms_id", sms.id)
            putExtra("address", sms.address)
            putExtra("body", sms.body)
            putExtra("date", sms.date)
            putExtra("type", sms.type)
        }
        startActivity(intent)
    }
    
    private fun markAsRead(smsId: String) {
        try {
            val values = ContentValues().apply { put(Telephony.Sms.READ, 1) }
            contentResolver.update(
                Telephony.Sms.CONTENT_URI,
                values,
                "${Telephony.Sms._ID} = ?",
                arrayOf(smsId)
            )
        } catch (e: Exception) {
            Log.e("READ_ERROR", "Error: ${e.message}")
        }
    }
    
    inner class GroupPagerAdapter : PagerAdapter() {
        
        override fun getCount(): Int = getAllGroups().size
        
        override fun isViewFromObject(view: View, obj: Any): Boolean = view == obj
        
        override fun instantiateItem(container: ViewGroup, position: Int): Any {
            val groups = getAllGroups()
            val groupName = groups[position]
            
            val list = when (groupName) {
                "All SMS" -> smsList
                "OTP" -> otpList
                "Finance" -> financeList
                "Personal" -> personalList
                "Promotions" -> promotionList
                else -> customGroups[groupName] ?: ArrayList()
            }
            
            val listView = ListView(this@SmsListActivity).apply {
                adapter = SmsAdapter(this@SmsListActivity, list)
                dividerHeight = 0
                setPadding(0, 8, 0, 8)
                
                setOnItemClickListener { parent, view, pos, id ->
                    if (pos < list.size) {
                        openSmsDetail(list[pos])
                    }
                }
            }
            
            container.addView(listView)
            return listView
        }
        
        override fun destroyItem(container: ViewGroup, position: Int, obj: Any) {
            container.removeView(obj as View)
        }
        
        override fun getPageTitle(position: Int): CharSequence {
            val groups = getAllGroups()
            return if (position < groups.size) groups[position] else ""
        }
    }
    
    inner class SmsAdapter(
        private val context: Context,
        private val items: List<SmsItem>
    ) : BaseAdapter() {
        
        @SuppressLint("SimpleDateFormat")
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val view = convertView ?: LayoutInflater.from(context)
                .inflate(R.layout.sms_list_item_dark, parent, false)
            
            try {
                if (position < items.size) {
                    val sms = items[position]
                    val cardView = view.findViewById<LinearLayout>(R.id.cardView)
                    val senderText = view.findViewById<TextView>(R.id.senderText)
                    val bodyText = view.findViewById<TextView>(R.id.bodyText)
                    val dateText = view.findViewById<TextView>(R.id.dateText)
                    val typeIcon = view.findViewById<TextView>(R.id.typeIcon)
                    
                    // Sender
                    val sender = if (sms.address.length > 20) sms.address.substring(0, 17) + "..." else sms.address
                    senderText.text = sender
                    senderText.setTextColor(Color.WHITE)
                    
                    // Date
                    val dateFormat = SimpleDateFormat("dd-MMM HH:mm", Locale.getDefault())
                    dateText.text = dateFormat.format(Date(sms.date))
                    dateText.setTextColor(Color.LTGRAY)
                    
                    // Body
                    val firstLine = sms.body.split("\n").firstOrNull() ?: sms.body
                    val truncatedBody = if (firstLine.length > 60) firstLine.substring(0, 57) + "..." else firstLine
                    bodyText.text = truncatedBody
                    bodyText.setTextColor(Color.WHITE)
                    
                    // Icon based on SMS type
                    typeIcon.text = if (sms.type == 1) "📥" else "📤"
                    typeIcon.setTextColor(Color.LTGRAY)
                    
                    // Unread indicator
                    if (!sms.read) {
                        senderText.setTypeface(senderText.typeface, Typeface.BOLD_ITALIC)
                    }
                }
            } catch (e: Exception) {
                Log.e("ADAPTER_ERROR", "Error: ${e.message}")
            }
            
            return view
        }
        
        override fun getCount(): Int = items.size
        
        override fun getItem(position: Int): SmsItem = items[position]
        
        override fun getItemId(position: Int): Long = position.toLong()
    }
}
