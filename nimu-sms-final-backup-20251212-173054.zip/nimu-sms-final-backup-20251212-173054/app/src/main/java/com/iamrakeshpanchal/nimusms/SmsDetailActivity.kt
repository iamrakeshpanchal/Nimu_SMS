package com.iamrakeshpanchal.nimusms

import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Telephony
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.*

class SmsDetailActivity : AppCompatActivity() {
    
    private lateinit var smsId: String
    private lateinit var phoneNumber: String
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Set dark theme
        setTheme(R.style.AppTheme_Dark)
        
        // Get SMS data
        smsId = intent.getStringExtra("sms_id") ?: ""
        phoneNumber = intent.getStringExtra("address") ?: ""
        val body = intent.getStringExtra("body") ?: ""
        val date = intent.getLongExtra("date", System.currentTimeMillis())
        
        // Create UI with dark theme
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 20, 20, 20)
            setBackgroundColor(Color.parseColor("#121212"))
        }
        
        // Header with back button
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = 20 }
        }
        
        val backBtn = Button(this).apply {
            text = "←"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.TRANSPARENT)
            setOnClickListener { finish() }
        }
        header.addView(backBtn)
        
        val headerText = TextView(this).apply {
            text = "Message Details"
            textSize = 18f
            setTextColor(Color.WHITE)
            setTypeface(null, android.graphics.Typeface.BOLD)
            layoutParams = LinearLayout.LayoutParams(
                0,
                LinearLayout.LayoutParams.WRAP_CONTENT,
                1.0f
            ).apply { leftMargin = 10 }
        }
        header.addView(headerText)
        
        layout.addView(header)
        
        // Card for sender info
        val senderCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 15, 20, 15)
            setBackgroundColor(Color.parseColor("#2D2D2D"))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = 15 }
        }
        
        val fromLabel = TextView(this).apply {
            text = "From:"
            textSize = 14f
            setTextColor(Color.LTGRAY)
        }
        senderCard.addView(fromLabel)
        
        val addressText = TextView(this).apply {
            text = phoneNumber
            textSize = 18f
            setTextColor(Color.WHITE)
            setPadding(0, 5, 0, 10)
        }
        senderCard.addView(addressText)
        
        val dateLabel = TextView(this).apply {
            text = "Date:"
            textSize = 14f
            setTextColor(Color.LTGRAY)
        }
        senderCard.addView(dateLabel)
        
        val dateText = TextView(this).apply {
            text = SimpleDateFormat("EEE, MMM dd yyyy HH:mm:ss", Locale.getDefault()).format(Date(date))
            textSize = 16f
            setTextColor(Color.WHITE)
        }
        senderCard.addView(dateText)
        
        layout.addView(senderCard)
        
        // Card for message body
        val bodyCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 20, 20, 20)
            setBackgroundColor(Color.parseColor("#2D2D2D"))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                0,
                1.0f
            ).apply { bottomMargin = 15 }
        }
        
        val bodyLabel = TextView(this).apply {
            text = "Message:"
            textSize = 14f
            setTextColor(Color.LTGRAY)
        }
        bodyCard.addView(bodyLabel)
        
        val bodyText = TextView(this).apply {
            text = body
            textSize = 16f
            setTextColor(Color.WHITE)
            setLineSpacing(1.2f, 1.2f)
            setPadding(0, 10, 0, 0)
        }
        bodyCard.addView(bodyText)
        
        layout.addView(bodyCard)
        
        // Action buttons
        val buttonLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }
        
        val replyBtn = Button(this).apply {
            text = "📝 Reply"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#4CAF50"))
            setPadding(20, 10, 20, 10)
            layoutParams = LinearLayout.LayoutParams(
                0,
                LinearLayout.LayoutParams.WRAP_CONTENT,
                1.0f
            ).apply { rightMargin = 5 }
            setOnClickListener { replyToSMS() }
        }
        buttonLayout.addView(replyBtn)
        
        val callBtn = Button(this).apply {
            text = "📞 Call"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#2196F3"))
            setPadding(20, 10, 20, 10)
            layoutParams = LinearLayout.LayoutParams(
                0,
                LinearLayout.LayoutParams.WRAP_CONTENT,
                1.0f
            ).apply { leftMargin = 5; rightMargin = 5 }
            setOnClickListener { callNumber() }
        }
        buttonLayout.addView(callBtn)
        
        val deleteBtn = Button(this).apply {
            text = "🗑️ Delete"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#F44336"))
            setPadding(20, 10, 20, 10)
            layoutParams = LinearLayout.LayoutParams(
                0,
                LinearLayout.LayoutParams.WRAP_CONTENT,
                1.0f
            ).apply { leftMargin = 5 }
            setOnClickListener { deleteSMS() }
        }
        buttonLayout.addView(deleteBtn)
        
        layout.addView(buttonLayout)
        
        val scrollView = ScrollView(this)
        scrollView.addView(layout)
        setContentView(scrollView)
    }
    
    private fun replyToSMS() {
        val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$phoneNumber"))
        intent.putExtra("sms_body", "")
        startActivity(intent)
    }
    
    private fun callNumber() {
        val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phoneNumber"))
        startActivity(intent)
    }
    
    private fun deleteSMS() {
        AlertDialog.Builder(this)
            .setTitle("Delete Message")
            .setMessage("Delete this message from $phoneNumber?")
            .setPositiveButton("🗑️ Delete") { _, _ ->
                try {
                    contentResolver.delete(
                        Telephony.Sms.CONTENT_URI,
                        "${Telephony.Sms._ID} = ?",
                        arrayOf(smsId)
                    )
                    Toast.makeText(this, "Message deleted", Toast.LENGTH_SHORT).show()
                    finish()
                } catch (e: Exception) {
                    Toast.makeText(this, "Delete failed", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
