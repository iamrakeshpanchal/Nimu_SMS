package com.iamrakeshpanchal.nimusms

import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class ComposeActivity : AppCompatActivity() {
    
    private lateinit var recipientEdit: EditText
    private lateinit var messageEdit: EditText
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Set dark theme
        setTheme(R.style.AppTheme_Dark)
        
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 20, 20, 20)
            setBackgroundColor(Color.parseColor("#121212"))
        }
        
        // Header with back button
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = 20 }
        }
        
        val backBtn = Button(this).apply {
            text = "←"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.TRANSPARENT)
            setOnClickListener { finish() }
        }
        header.addView(backBtn)
        
        val headerText = TextView(this).apply {
            text = "Compose Message"
            textSize = 18f
            setTextColor(Color.WHITE)
            setTypeface(null, android.graphics.Typeface.BOLD)
            layoutParams = LinearLayout.LayoutParams(
                0,
                LinearLayout.LayoutParams.WRAP_CONTENT,
                1.0f
            ).apply { leftMargin = 10 }
        }
        header.addView(headerText)
        
        layout.addView(header)
        
        // Recipient card
        val recipientCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 15, 20, 15)
            setBackgroundColor(Color.parseColor("#2D2D2D"))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = 15 }
        }
        
        val recipientLabel = TextView(this).apply {
            text = "To:"
            textSize = 14f
            setTextColor(Color.LTGRAY)
        }
        recipientCard.addView(recipientLabel)
        
        recipientEdit = EditText(this).apply {
            hint = "Phone number"
            setHintTextColor(Color.GRAY)
            textSize = 18f
            setTextColor(Color.WHITE)
            setSingleLine(true)
            setBackgroundColor(Color.parseColor("#1E1E1E"))
            setPadding(20, 15, 20, 15)
        }
        recipientCard.addView(recipientEdit)
        
        layout.addView(recipientCard)
        
        // Message card
        val messageCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 15, 20, 15)
            setBackgroundColor(Color.parseColor("#2D2D2D"))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                0,
                1.0f
            ).apply { bottomMargin = 15 }
        }
        
        val messageLabel = TextView(this).apply {
            text = "Message:"
            textSize = 14f
            setTextColor(Color.LTGRAY)
        }
        messageCard.addView(messageLabel)
        
        messageEdit = EditText(this).apply {
            hint = "Type your message..."
            setHintTextColor(Color.GRAY)
            textSize = 16f
            setTextColor(Color.WHITE)
            minLines = 6
            setBackgroundColor(Color.parseColor("#1E1E1E"))
            setPadding(20, 15, 20, 15)
        }
        messageCard.addView(messageEdit)
        
        layout.addView(messageCard)
        
        // Buttons
        val buttonLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }
        
        val sendBtn = Button(this).apply {
            text = "📤 Send"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#4CAF50"))
            setPadding(20, 15, 20, 15)
            layoutParams = LinearLayout.LayoutParams(
                0,
                LinearLayout.LayoutParams.WRAP_CONTENT,
                1.0f
            ).apply { rightMargin = 10 }
            setOnClickListener { sendMessage() }
        }
        buttonLayout.addView(sendBtn)
        
        val cancelBtn = Button(this).apply {
            text = "Cancel"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#666666"))
            setPadding(20, 15, 20, 15)
            layoutParams = LinearLayout.LayoutParams(
                0,
                LinearLayout.LayoutParams.WRAP_CONTENT,
                1.0f
            )
            setOnClickListener { finish() }
        }
        buttonLayout.addView(cancelBtn)
        
        layout.addView(buttonLayout)
        
        setContentView(layout)
        
        // Check intent for pre-filled data
        handleIntent(intent)
    }
    
    private fun handleIntent(intent: Intent) {
        val data = intent.data
        if (data != null) {
            // Handle smsto:, sms:, mms:, mmsto: URIs
            val recipient = data.schemeSpecificPart
            if (recipient.contains(":")) {
                recipientEdit.setText(recipient.substringBefore(":"))
            } else {
                recipientEdit.setText(recipient)
            }
        }
        
        // Check for extra text
        val message = intent.getStringExtra("sms_body") ?: intent.getStringExtra(Intent.EXTRA_TEXT)
        if (!message.isNullOrEmpty()) {
            messageEdit.setText(message)
        }
    }
    
    private fun sendMessage() {
        val recipient = recipientEdit.text.toString().trim()
        val message = messageEdit.text.toString().trim()
        
        if (recipient.isEmpty()) {
            Toast.makeText(this, "Please enter recipient", Toast.LENGTH_SHORT).show()
            return
        }
        
        if (message.isEmpty()) {
            Toast.makeText(this, "Please enter message", Toast.LENGTH_SHORT).show()
            return
        }
        
        try {
            val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$recipient"))
            intent.putExtra("sms_body", message)
            startActivity(intent)
            Toast.makeText(this, "Sending message...", Toast.LENGTH_SHORT).show()
            finish()
        } catch (e: Exception) {
            Toast.makeText(this, "Error sending message", Toast.LENGTH_SHORT).show()
        }
    }
}
