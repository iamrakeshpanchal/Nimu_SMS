package com.iamrakeshpanchal.nimusms

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Intent
import android.database.Cursor
import android.os.Bundle
import android.provider.Telephony
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.*

class SmsListActivity : AppCompatActivity() {
    
    private lateinit var listView: ListView
    private lateinit var emptyText: TextView
    
    private val smsList = ArrayList<SmsItem>()
    private lateinit var adapter: SmsAdapter
    
    data class SmsItem(
        val id: String,
        val address: String,
        val body: String,
        val date: Long,
        val type: Int,
        val read: Boolean
    )
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Create UI programmatically with better structure
        val mainLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT
            )
        }
        
        // Title at TOP
        val title = TextView(this).apply {
            text = "📨 SMS Messages"
            textSize = 20f
            gravity = android.view.Gravity.CENTER
            setPadding(0, 20, 0, 20)
        }
        mainLayout.addView(title)
        
        // FrameLayout to hold both ListView and Empty TextView
        val frameLayout = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                0,
                1.0f
            )
        }
        
        // ListView for SMS
        listView = ListView(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        }
        frameLayout.addView(listView)
        
        // Empty text (centered, overlays ListView when empty)
        emptyText = TextView(this).apply {
            text = "Loading SMS..."
            gravity = android.view.Gravity.CENTER
            textSize = 16f
            setPadding(0, 100, 0, 0)
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        }
        frameLayout.addView(emptyText)
        
        mainLayout.addView(frameLayout)
        
        // Settings button at BOTTOM
        val settingsBtn = Button(this).apply {
            text = "⚙️ Settings"
            setTextColor(0xFF000000.toInt())
            setOnClickListener {
                finish() // Go back to main screen
            }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(16, 8, 16, 16)
            }
        }
        mainLayout.addView(settingsBtn)
        
        setContentView(mainLayout)
        
        // Setup adapter with custom layout
        adapter = SmsAdapter(this, smsList)
        listView.adapter = adapter
        
        // Click to open SMS detail - FIXED
        listView.onItemClickListener = AdapterView.OnItemClickListener { parent, view, position, id ->
            Log.d("SMS_CLICK", "Clicked position: $position")
            val sms = smsList[position]
            openSmsDetail(sms)
        }
        
        // Long press to delete
        listView.onItemLongClickListener = AdapterView.OnItemLongClickListener { parent, view, position, id ->
            deleteSMS(position)
            true
        }
        
        // Load SMS
        loadSMS()
    }
    
    @SuppressLint("Range")
    private fun loadSMS() {
        emptyText.text = "Loading SMS..."
        
        Thread {
            try {
                val cursor: Cursor? = contentResolver.query(
                    Telephony.Sms.CONTENT_URI,
                    arrayOf(
                        Telephony.Sms._ID,
                        Telephony.Sms.ADDRESS,
                        Telephony.Sms.BODY,
                        Telephony.Sms.DATE,
                        Telephony.Sms.TYPE,
                        Telephony.Sms.READ
                    ),
                    null, null, "${Telephony.Sms.DATE} DESC LIMIT 100"
                )
                
                cursor?.use {
                    while (it.moveToNext()) {
                        val id = it.getString(it.getColumnIndex(Telephony.Sms._ID))
                        val address = it.getString(it.getColumnIndex(Telephony.Sms.ADDRESS)) ?: "Unknown"
                        val body = it.getString(it.getColumnIndex(Telephony.Sms.BODY)) ?: ""
                        val date = it.getLong(it.getColumnIndex(Telephony.Sms.DATE))
                        val type = it.getInt(it.getColumnIndex(Telephony.Sms.TYPE))
                        val read = it.getInt(it.getColumnIndex(Telephony.Sms.READ)) == 1
                        
                        smsList.add(SmsItem(id, address, body, date, type, read))
                    }
                }
                
                runOnUiThread {
                    adapter.notifyDataSetChanged()
                    if (smsList.isEmpty()) {
                        emptyText.text = "No SMS messages found"
                        emptyText.visibility = View.VISIBLE
                        listView.visibility = View.GONE
                    } else {
                        emptyText.visibility = View.GONE
                        listView.visibility = View.VISIBLE
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
                runOnUiThread {
                    emptyText.text = "Error: ${e.message}"
                }
            }
        }.start()
    }
    
    private fun openSmsDetail(sms: SmsItem) {
        Log.d("SMS_CLICK", "Opening detail for SMS ID: ${sms.id}")
        
        // Mark as read
        markAsRead(sms.id)
        
        // Open detail activity
        val intent = Intent(this, SmsDetailActivity::class.java).apply {
            putExtra("sms_id", sms.id)
            putExtra("address", sms.address)
            putExtra("body", sms.body)
            putExtra("date", sms.date)
            putExtra("type", sms.type)
        }
        startActivity(intent)
    }
    
    private fun markAsRead(smsId: String) {
        try {
            val values = ContentValues().apply { put(Telephony.Sms.READ, 1) }
            contentResolver.update(
                Telephony.Sms.CONTENT_URI,
                values,
                "${Telephony.Sms._ID} = ?",
                arrayOf(smsId)
            )
        } catch (e: Exception) {
            Log.e("SMS_READ", "Error marking as read: ${e.message}")
        }
    }
    
    private fun deleteSMS(position: Int) {
        val sms = smsList[position]
        AlertDialog.Builder(this)
            .setTitle("Delete Message")
            .setMessage("Delete message from ${sms.address}?")
            .setPositiveButton("🗑️ Delete") { _, _ ->
                try {
                    contentResolver.delete(
                        Telephony.Sms.CONTENT_URI,
                        "${Telephony.Sms._ID} = ?",
                        arrayOf(sms.id)
                    )
                    smsList.removeAt(position)
                    adapter.notifyDataSetChanged()
                    Toast.makeText(this, "Message deleted", Toast.LENGTH_SHORT).show()
                    
                    if (smsList.isEmpty()) {
                        emptyText.text = "No SMS messages"
                        emptyText.visibility = View.VISIBLE
                        listView.visibility = View.GONE
                    }
                } catch (e: Exception) {
                    Toast.makeText(this, "Delete failed", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
    
    inner class SmsAdapter(
        private val context: android.content.Context,
        private val items: List<SmsItem>
    ) : BaseAdapter() {
        
        @SuppressLint("SimpleDateFormat")
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val view = convertView ?: LayoutInflater.from(context)
                .inflate(android.R.layout.simple_list_item_2, parent, false)
            
            val sms = items[position]
            val text1 = view.findViewById<TextView>(android.R.id.text1)
            val text2 = view.findViewById<TextView>(android.R.id.text2)
            
            val typeIcon = when(sms.type) {
                Telephony.Sms.MESSAGE_TYPE_INBOX -> "📥 "
                Telephony.Sms.MESSAGE_TYPE_SENT -> "📤 "
                else -> "📱 "
            }
            
            val unreadIndicator = if (!sms.read) "🔵 " else ""
            
            text1.text = "$unreadIndicator$typeIcon${sms.address}"
            text2.text = "${sms.body.take(80)}...\n${SimpleDateFormat("MMM dd, HH:mm").format(Date(sms.date))}"
            
            // Make sure the view is clickable
            view.isClickable = false // Important! Let the ListView handle clicks
            view.isFocusable = false
            
            return view
        }
        
        override fun getCount(): Int = items.size
        
        override fun getItem(position: Int): SmsItem = items[position]
        
        override fun getItemId(position: Int): Long = position.toLong()
    }
}
