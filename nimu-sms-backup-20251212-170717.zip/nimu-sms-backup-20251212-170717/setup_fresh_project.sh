#!/bin/bash

echo "🚀 Creating fresh Android project..."

# Backup existing
echo "📦 Backing up existing files..."
mkdir -p backup
timestamp=$(date +%s)
if [ -d "app" ]; then
    mv app backup/app_$timestamp
fi
[ -f "build.gradle.kts" ] && mv build.gradle.kts backup/build_$timestamp.gradle.kts
[ -f "settings.gradle.kts" ] && mv settings.gradle.kts backup/settings_$timestamp.gradle.kts

# Create fresh structure
echo "📁 Creating project structure..."
mkdir -p app/src/main/java/com/iamrakeshpanchal/nimusms
mkdir -p app/src/main/res/{layout,values}

# Create settings.gradle.kts
echo "⚙️  Creating settings.gradle.kts..."
cat > settings.gradle.kts << 'SETTINGS_EOF'
pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.PREFER_SETTINGS)
    repositories {
        google()
        mavenCentral()
    }
}
rootProject.name = "NimuSMS"
include(":app")
SETTINGS_EOF

# Create root build.gradle.kts
echo "🔨 Creating root build.gradle.kts..."
cat > build.gradle.kts << 'ROOT_EOF'
// Top-level build file where you can add configuration options common to all sub-projects/modules.
plugins {
    id("com.android.application") version "8.3.0" apply false
    id("org.jetbrains.kotlin.android") version "1.9.20" apply false
}
ROOT_EOF

# Create app build.gradle.kts
echo "📱 Creating app/build.gradle.kts..."
cat > app/build.gradle.kts << 'APP_EOF'
plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.iamrakeshpanchal.nimusms"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.iamrakeshpanchal.nimusms"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.11.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.1.5")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.5.1")
}
APP_EOF

# Create AndroidManifest.xml
echo "📄 Creating AndroidManifest.xml..."
cat > app/src/main/AndroidManifest.xml << 'MANIFEST_EOF'
<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">
    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="Nimu SMS"
        android:theme="@style/Theme.AppCompat.Light">
        <activity
            android:name=".MainActivity"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>
MANIFEST_EOF

# Create MainActivity.kt
echo "🎯 Creating MainActivity.kt..."
cat > app/src/main/java/com/iamrakeshpanchal/nimusms/MainActivity.kt << 'ACTIVITY_EOF'
package com.iamrakeshpanchal.nimusms

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
}
ACTIVITY_EOF

# Create activity_main.xml
echo "🎨 Creating activity_main.xml..."
cat > app/src/main/res/layout/activity_main.xml << 'LAYOUT_EOF'
<?xml version="1.0" encoding="utf-8"?>
<androidx.constraintlayout.widget.ConstraintLayout 
    xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:app="http://schemas.android.com/apk/res-auto"
    android:layout_width="match_parent"
    android:layout_height="match_parent">

    <TextView
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="Hello Nimu SMS!"
        app:layout_constraintBottom_toBottomOf="parent"
        app:layout_constraintLeft_toLeftOf="parent"
        app:layout_constraintRight_toRightOf="parent"
        app:layout_constraintTop_toTopOf="parent" />

</androidx.constraintlayout.widget.ConstraintLayout>
LAYOUT_EOF

# Create strings.xml
echo "🔤 Creating strings.xml..."
cat > app/src/main/res/values/strings.xml << 'STRINGS_EOF'
<resources>
    <string name="app_name">Nimu SMS</string>
</resources>
STRINGS_EOF

# Create proguard-rules.pro
echo "🛡️ Creating proguard-rules.pro..."
touch app/proguard-rules.pro

echo "✅ Project setup complete!"
echo "📋 Running gradle sync..."
./gradlew sync

if [ $? -eq 0 ]; then
    echo "🎉 Sync successful! Building project..."
    ./gradlew build
else
    echo "❌ Sync failed. Checking configuration..."
    ./gradlew --version
fi
