package com.iamrakeshpanchal.nimusms.workers

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.iamrakeshpanchal.nimusms.NimuSMSApplication
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.*

class OtpCleanupWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {
    
    override suspend fun doWork(): Result {
        return try {
            withContext(Dispatchers.IO) {
                val database = NimuSMSApplication.database
                val smsDao = database.smsDao()
                
                // Delete OTPs older than 24 hours
                val expiryTime = System.currentTimeMillis() - (24 * 60 * 60 * 1000)
                smsDao.deleteExpiredOtps(expiryTime)
                
                // Also delete expired OTPs based on their expiry field
                val currentTime = Date().time
                val otpMessages = smsDao.getOtpMessages(0)
                otpMessages.forEach { sms ->
                    sms.otpExpiry?.let { expiry ->
                        if (expiry < currentTime) {
                            smsDao.deleteMessage(sms)
                        }
                    }
                }
            }
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }
}
