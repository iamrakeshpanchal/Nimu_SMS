package com.iamrakeshpanchal.nimusms

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.provider.Telephony
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Set dark theme
        setTheme(R.style.AppTheme_Dark)
        
        // Check intent
        if (intent?.action == Intent.ACTION_SENDTO || 
            intent?.action == Intent.ACTION_SEND ||
            intent?.action == Intent.ACTION_VIEW) {
            
            val data = intent.data
            if (data != null && (data.scheme == "sms" || data.scheme == "smsto" || 
                                data.scheme == "mms" || data.scheme == "mmsto")) {
                val composeIntent = Intent(this, ComposeActivity::class.java)
                composeIntent.data = intent.data
                composeIntent.putExtras(intent)
                startActivity(composeIntent)
                finish()
                return
            }
        }
        
        showMainScreen()
    }
    
    private fun showMainScreen() {
        // Create dark theme UI
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 80, 40, 40)
            setBackgroundColor(Color.parseColor("#121212"))
        }
        
        // Balloon icon at top
        val balloonIcon = TextView(this).apply {
            text = "💬"
            textSize = 60f
            gravity = android.view.Gravity.CENTER
            setPadding(0, 0, 0, 20)
        }
        layout.addView(balloonIcon)
        
        // App name
        val appName = TextView(this).apply {
            text = "Nimu SMS"
            textSize = 28f
            setTextColor(Color.WHITE)
            gravity = android.view.Gravity.CENTER
            setPadding(0, 0, 0, 10)
        }
        layout.addView(appName)
        
        // Tagline
        val tagline = TextView(this).apply {
            text = "Smart SMS Manager"
            textSize = 16f
            setTextColor(Color.LTGRAY)
            gravity = android.view.Gravity.CENTER
            setPadding(0, 0, 0, 50)
        }
        layout.addView(tagline)
        
        // Load SMS Button
        val loadBtn = Button(this).apply {
            text = "View SMS Messages"
            setTextColor(Color.WHITE)
            setBackgroundResource(R.drawable.rounded_button)
            setPadding(0, 20, 0, 20)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = 20 }
            setOnClickListener {
                checkPermissions()
            }
        }
        layout.addView(loadBtn)
        
        // Compose Button
        val composeBtn = Button(this).apply {
            text = "Compose Message"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#2196F3"))
            background = loadBtn.background // Same rounded style
            setPadding(0, 20, 0, 20)
            setOnClickListener {
                val intent = Intent(this@MainActivity, ComposeActivity::class.java)
                startActivity(intent)
            }
        }
        layout.addView(composeBtn)
        
        setContentView(layout)
        
        // Check permissions
        checkPermissions()
    }
    
    private fun checkPermissions() {
        val permissions = arrayOf(
            Manifest.permission.READ_SMS,
            Manifest.permission.SEND_SMS,
            Manifest.permission.READ_CONTACTS
        )
        
        val missingPermissions = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        
        if (missingPermissions.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, missingPermissions.toTypedArray(), 100)
        } else {
            openSmsList()
        }
    }
    
    private fun openSmsList() {
        startActivity(Intent(this, SmsListActivity::class.java))
    }
    
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 100) {
            if (grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) {
                openSmsList()
            } else {
                Toast.makeText(this, "Permissions required", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
