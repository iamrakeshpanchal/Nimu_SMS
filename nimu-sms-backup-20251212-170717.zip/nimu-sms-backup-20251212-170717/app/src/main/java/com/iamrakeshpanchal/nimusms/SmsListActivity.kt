package com.iamrakeshpanchal.nimusms

import android.annotation.SuppressLint
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.database.Cursor
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Telephony
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.viewpager.widget.PagerAdapter
import androidx.viewpager.widget.ViewPager
import java.text.SimpleDateFormat
import java.util.*

class SmsListActivity : AppCompatActivity() {
    
    private lateinit var viewPager: ViewPager
    private lateinit var searchBox: EditText
    private lateinit var smsCountText: TextView
    private lateinit var groupTabs: LinearLayout
    
    private val smsList = ArrayList<SmsItem>()
    private val otpList = ArrayList<SmsItem>()
    private val financeList = ArrayList<SmsItem>()
    private val personalList = ArrayList<SmsItem>()
    private val promotionList = ArrayList<SmsItem>()
    
    private lateinit var backupManager: BackupManager
    
    // Group colors
    private val groupColors = mutableMapOf(
        "All SMS" to "#4CAF50",
        "OTP" to "#2196F3",
        "Finance" to "#FF9800",
        "Personal" to "#9C27B0",
        "Promotions" to "#F44336"
    )
    
    data class SmsItem(
        val id: String,
        val address: String,
        val body: String,
        val date: Long,
        val type: Int,
        val read: Boolean
    )
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Set dark theme
        setTheme(R.style.AppTheme_Dark)
        
        // Initialize backup manager
        backupManager = BackupManager(this)
        
        // Create UI
        val mainLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(Color.parseColor("#121212"))
        }
        
        // Search bar with icons
        val searchBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setPadding(15, 15, 15, 15)
            }
            setBackgroundColor(Color.parseColor("#1E1E1E"))
        }
        
        // Search icon
        val searchIcon = TextView(this).apply {
            text = "��"
            textSize = 20f
            setTextColor(Color.WHITE)
            setPadding(10, 0, 15, 0)
        }
        searchBar.addView(searchIcon)
        
        // Search box
        searchBox = EditText(this).apply {
            hint = "Search messages..."
            setHintTextColor(Color.GRAY)
            textSize = 16f
            setTextColor(Color.WHITE)
            setSingleLine(true)
            setBackgroundResource(R.drawable.rounded_search)
            setPadding(20, 15, 20, 15)
            layoutParams = LinearLayout.LayoutParams(
                0,
                LinearLayout.LayoutParams.WRAP_CONTENT,
                1.0f
            )
        }
        searchBar.addView(searchBox)
        
        // Compose button in search bar
        val composeBtn = Button(this).apply {
            text = "✉️"
            textSize = 18f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.TRANSPARENT)
            setPadding(10, 0, 10, 0)
            setOnClickListener {
                val intent = Intent(this@SmsListActivity, ComposeActivity::class.java)
                startActivity(intent)
            }
        }
        searchBar.addView(composeBtn)
        
        // Three-dot menu in search bar
        val menuBtn = Button(this).apply {
            text = "⋮"
            textSize = 22f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.TRANSPARENT)
            setPadding(10, 0, 10, 0)
            setOnClickListener { showThreeDotMenu() }
        }
        searchBar.addView(menuBtn)
        
        mainLayout.addView(searchBar)
        
        // Group tabs - Rounded
        groupTabs = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setPadding(10, 10, 10, 10)
            }
            setBackgroundColor(Color.parseColor("#1E1E1E"))
        }
        mainLayout.addView(groupTabs)
        
        // SMS Count
        smsCountText = TextView(this).apply {
            text = "Messages: 0"
            textSize = 14f
            setTextColor(Color.LTGRAY)
            setPadding(20, 5, 20, 15)
            setBackgroundColor(Color.parseColor("#1E1E1E"))
        }
        mainLayout.addView(smsCountText)
        
        // Divider line
        val divider = View(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                1
            )
            setBackgroundColor(Color.parseColor("#333333"))
        }
        mainLayout.addView(divider)
        
        // ViewPager for swipeable groups
        viewPager = ViewPager(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                0,
                1.0f
            )
        }
        mainLayout.addView(viewPager)
        
        setContentView(mainLayout)
        
        // Setup ViewPager
        viewPager.adapter = GroupPagerAdapter()
        viewPager.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {
            override fun onPageSelected(position: Int) {
                updateGroupSelection(position)
            }
            override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {}
            override fun onPageScrollStateChanged(state: Int) {}
        })
        
        // Search listener
        searchBox.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                filterSMS()
            }
        })
        
        // Load SMS
        loadAllSMS()
    }
    
    private fun updateGroupSelection(position: Int) {
        val groups = listOf("All SMS", "OTP", "Finance", "Personal", "Promotions")
        
        // Update tab colors with rounded corners
        for (i in 0 until groupTabs.childCount) {
            val tab = groupTabs.getChildAt(i) as? Button
            tab?.let {
                if (i == position) {
                    it.setTextColor(Color.WHITE)
                    it.setBackgroundResource(R.drawable.rounded_tab_selected)
                    // Set dynamic color
                    it.setBackgroundColor(Color.parseColor(groupColors[groups[i]] ?: "#4CAF50"))
                } else {
                    it.setTextColor(Color.parseColor(groupColors[groups[i]] ?: "#4CAF50"))
                    it.setBackgroundResource(R.drawable.rounded_tab_unselected)
                    it.setTextColor(Color.parseColor(groupColors[groups[i]] ?: "#4CAF50"))
                }
            }
        }
        
        // Update count
        updateSmsCount()
    }
    
    private fun createGroupTabs() {
        groupTabs.removeAllViews()
        val groups = listOf("All SMS", "OTP", "Finance", "Personal", "Promotions")
        
        for ((index, group) in groups.withIndex()) {
            val tab = Button(this).apply {
                text = group
                textSize = 12f
                setPadding(15, 10, 15, 10)
                layoutParams = LinearLayout.LayoutParams(
                    0,
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    1.0f
                ).apply {
                    setMargins(4, 4, 4, 4)
                }
                setOnClickListener {
                    viewPager.currentItem = index
                }
            }
            groupTabs.addView(tab)
        }
        
        // Set initial selection
        updateGroupSelection(0)
    }
    
    private fun showThreeDotMenu() {
        val menuItems = arrayOf(
            "Backup SMS",
            "Restore Backup",
            "Change Group Colors",
            "Settings",
            "Configure Groups",
            "About"
        )
        
        // Create rounded dialog
        val dialog = AlertDialog.Builder(this)
            .setTitle("Menu")
            .setItems(menuItems) { dialog, which ->
                when (which) {
                    0 -> backupSMS()
                    1 -> restoreBackup()
                    2 -> changeGroupColors()
                    3 -> showSettings()
                    4 -> configureGroups()
                    5 -> showAbout()
                }
            }
            .setNegativeButton("Cancel", null)
            .create()
        
        dialog.window?.setBackgroundDrawableResource(R.drawable.rounded_card)
        dialog.show()
    }
    
    private fun backupSMS() {
        if (backupManager.backupSMS(smsList)) {
            Toast.makeText(this, "Backup created", Toast.LENGTH_SHORT).show()
        }
    }
    
    private fun restoreBackup() {
        val backupFiles = backupManager.getBackupFiles()
        if (backupFiles.isEmpty()) {
            Toast.makeText(this, "No backups found", Toast.LENGTH_SHORT).show()
            return
        }
        
        val fileNames = backupFiles.map { it.name }.toTypedArray()
        
        AlertDialog.Builder(this)
            .setTitle("Select Backup")
            .setItems(fileNames) { dialog, which ->
                backupManager.restoreBackup(backupFiles[which])
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
    
    private fun changeGroupColors() {
        val groups = listOf("All SMS", "OTP", "Finance", "Personal", "Promotions")
        val colors = arrayOf("Green", "Blue", "Orange", "Purple", "Red", "Custom...")
        
        AlertDialog.Builder(this)
            .setTitle("Select Group")
            .setItems(groups.toTypedArray()) { dialog, groupIndex ->
                AlertDialog.Builder(this)
                    .setTitle("Color for ${groups[groupIndex]}")
                    .setItems(colors) { dialog2, colorIndex ->
                        val colorHex = when (colorIndex) {
                            0 -> "#4CAF50"
                            1 -> "#2196F3"
                            2 -> "#FF9800"
                            3 -> "#9C27B0"
                            4 -> "#F44336"
                            5 -> {
                                showColorPicker(groups[groupIndex])
                                return@setItems
                            }
                            else -> "#4CAF50"
                        }
                        groupColors[groups[groupIndex]] = colorHex
                        createGroupTabs()
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
    
    private fun showColorPicker(groupName: String) {
        val input = EditText(this)
        input.hint = "#RRGGBB"
        input.setBackgroundResource(R.drawable.rounded_search)
        input.setPadding(20, 15, 20, 15)
        
        AlertDialog.Builder(this)
            .setTitle("Enter Color for $groupName")
            .setView(input)
            .setPositiveButton("Set") { dialog, which ->
                val color = input.text.toString().trim()
                if (color.matches("#[0-9A-Fa-f]{6}".toRegex())) {
                    groupColors[groupName] = color
                    createGroupTabs()
                } else {
                    Toast.makeText(this, "Invalid color", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
    
    private fun showSettings() {
        Toast.makeText(this, "Settings", Toast.LENGTH_SHORT).show()
    }
    
    private fun configureGroups() {
        Toast.makeText(this, "Configure Groups", Toast.LENGTH_SHORT).show()
    }
    
    private fun showAbout() {
        AlertDialog.Builder(this)
            .setTitle("About")
            .setMessage("Nimu SMS v2.0\nDark Theme • Backup • Smart Groups")
            .setPositiveButton("OK", null)
            .show()
    }
    
    private fun filterSMS() {
        val query = searchBox.text.toString().trim().lowercase(Locale.getDefault())
        
        otpList.clear()
        financeList.clear()
        personalList.clear()
        promotionList.clear()
        
        for (sms in smsList) {
            if (query.isEmpty() || sms.address.lowercase(Locale.getDefault()).contains(query) ||
                sms.body.lowercase(Locale.getDefault()).contains(query)) {
                
                when {
                    isOtpSms(sms) -> otpList.add(sms)
                    isFinanceSms(sms) -> financeList.add(sms)
                    isPromotionSms(sms) -> promotionList.add(sms)
                    else -> personalList.add(sms)
                }
            }
        }
        
        // Notify adapter
        viewPager.adapter?.notifyDataSetChanged()
        updateSmsCount()
    }
    
    private fun updateSmsCount() {
        val position = viewPager.currentItem
        val count = when (position) {
            0 -> smsList.size
            1 -> otpList.size
            2 -> financeList.size
            3 -> personalList.size
            4 -> promotionList.size
            else -> 0
        }
        smsCountText.text = "Messages: $count"
    }
    
    private fun isOtpSms(sms: SmsItem): Boolean {
        val body = sms.body.lowercase(Locale.getDefault())
        return body.contains("otp") || body.contains("verification") ||
               "\\d{4,6}".toRegex().containsMatchIn(body)
    }
    
    private fun isFinanceSms(sms: SmsItem): Boolean {
        val body = sms.body.lowercase(Locale.getDefault())
        val financeWords = listOf("bank", "upi", "payment", "transaction", "debit", "credit", "balance")
        return financeWords.any { body.contains(it) }
    }
    
    private fun isPromotionSms(sms: SmsItem): Boolean {
        val body = sms.body.lowercase(Locale.getDefault())
        val promoWords = listOf("offer", "discount", "sale", "deal", "coupon", "shop", "buy")
        return promoWords.any { body.contains(it) }
    }
    
    @SuppressLint("Range")
    private fun loadAllSMS() {
        Thread {
            try {
                val cursor: Cursor? = contentResolver.query(
                    Telephony.Sms.CONTENT_URI,
                    arrayOf(
                        Telephony.Sms._ID,
                        Telephony.Sms.ADDRESS,
                        Telephony.Sms.BODY,
                        Telephony.Sms.DATE,
                        Telephony.Sms.TYPE,
                        Telephony.Sms.READ
                    ),
                    null, null, "${Telephony.Sms.DATE} DESC"
                )
                
                cursor?.use {
                    smsList.clear()
                    while (it.moveToNext()) {
                        val id = it.getString(it.getColumnIndex(Telephony.Sms._ID))
                        val address = it.getString(it.getColumnIndex(Telephony.Sms.ADDRESS)) ?: "Unknown"
                        val body = it.getString(it.getColumnIndex(Telephony.Sms.BODY)) ?: ""
                        val date = it.getLong(it.getColumnIndex(Telephony.Sms.DATE))
                        val type = it.getInt(it.getColumnIndex(Telephony.Sms.TYPE))
                        val read = it.getInt(it.getColumnIndex(Telephony.Sms.READ)) == 1
                        
                        smsList.add(SmsItem(id, address, body, date, type, read))
                    }
                }
                
                runOnUiThread {
                    createGroupTabs()
                    filterSMS()
                }
            } catch (e: Exception) {
                Log.e("LOAD_ERROR", "Error: ${e.message}")
            }
        }.start()
    }
    
    private fun copyOtpToClipboard(otp: String) {
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText("OTP", otp)
        clipboard.setPrimaryClip(clip)
        Toast.makeText(this, "OTP copied: $otp", Toast.LENGTH_SHORT).show()
    }
    
    private fun extractOtp(text: String): String? {
        val pattern = "\\b\\d{4,6}\\b".toRegex()
        return pattern.find(text)?.value
    }
    
    private fun openSmsDetail(sms: SmsItem) {
        // Auto-copy OTP if present
        if (isOtpSms(sms)) {
            val otp = extractOtp(sms.body)
            otp?.let { copyOtpToClipboard(it) }
        }
        
        // Mark as read
        markAsRead(sms.id)
        
        // Open detail
        val intent = Intent(this, SmsDetailActivity::class.java).apply {
            putExtra("sms_id", sms.id)
            putExtra("address", sms.address)
            putExtra("body", sms.body)
            putExtra("date", sms.date)
            putExtra("type", sms.type)
        }
        startActivity(intent)
    }
    
    private fun markAsRead(smsId: String) {
        try {
            val values = ContentValues().apply { put(Telephony.Sms.READ, 1) }
            contentResolver.update(
                Telephony.Sms.CONTENT_URI,
                values,
                "${Telephony.Sms._ID} = ?",
                arrayOf(smsId)
            )
        } catch (e: Exception) {
            Log.e("READ_ERROR", "Error: ${e.message}")
        }
    }
    
    inner class GroupPagerAdapter : PagerAdapter() {
        
        override fun getCount(): Int = 5
        
        override fun isViewFromObject(view: View, obj: Any): Boolean = view == obj
        
        override fun instantiateItem(container: ViewGroup, position: Int): Any {
            val list = when (position) {
                0 -> smsList
                1 -> otpList
                2 -> financeList
                3 -> personalList
                4 -> promotionList
                else -> smsList
            }
            
            val listView = ListView(this@SmsListActivity).apply {
                adapter = SmsAdapter(this@SmsListActivity, list)
                dividerHeight = 0
                setPadding(0, 10, 0, 10)
                
                setOnItemClickListener { parent, view, pos, id ->
                    if (pos < list.size) {
                        openSmsDetail(list[pos])
                    }
                }
            }
            
            container.addView(listView)
            return listView
        }
        
        override fun destroyItem(container: ViewGroup, position: Int, obj: Any) {
            container.removeView(obj as View)
        }
        
        override fun getPageTitle(position: Int): CharSequence {
            return when (position) {
                0 -> "All SMS"
                1 -> "OTP"
                2 -> "Finance"
                3 -> "Personal"
                4 -> "Promotions"
                else -> ""
            }
        }
    }
    
    inner class SmsAdapter(
        private val context: Context,
        private val items: List<SmsItem>
    ) : BaseAdapter() {
        
        @SuppressLint("SimpleDateFormat")
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val view = convertView ?: LayoutInflater.from(context)
                .inflate(R.layout.sms_list_item_dark, parent, false)
            
            try {
                if (position < items.size) {
                    val sms = items[position]
                    val cardView = view.findViewById<LinearLayout>(R.id.cardView)
                    val senderText = view.findViewById<TextView>(R.id.senderText)
                    val bodyText = view.findViewById<TextView>(R.id.bodyText)
                    val dateText = view.findViewById<TextView>(R.id.dateText)
                    val typeIcon = view.findViewById<TextView>(R.id.typeIcon)
                    
                    // Sender
                    val sender = if (sms.address.length > 20) sms.address.substring(0, 17) + "..." else sms.address
                    senderText.text = sender
                    senderText.setTextColor(Color.WHITE)
                    
                    // Date
                    val dateFormat = SimpleDateFormat("dd-MMM HH:mm", Locale.getDefault())
                    dateText.text = dateFormat.format(Date(sms.date))
                    dateText.setTextColor(Color.LTGRAY)
                    
                    // Body
                    val firstLine = sms.body.split("\n").firstOrNull() ?: sms.body
                    val truncatedBody = if (firstLine.length > 60) firstLine.substring(0, 57) + "..." else firstLine
                    bodyText.text = truncatedBody
                    bodyText.setTextColor(Color.WHITE)
                    
                    // Icon
                    when {
                        isOtpSms(sms) -> {
                            typeIcon.text = "🔐"
                            typeIcon.setTextColor(Color.parseColor(groupColors["OTP"] ?: "#2196F3"))
                        }
                        isFinanceSms(sms) -> {
                            typeIcon.text = "💰"
                            typeIcon.setTextColor(Color.parseColor(groupColors["Finance"] ?: "#FF9800"))
                        }
                        isPromotionSms(sms) -> {
                            typeIcon.text = "🎯"
                            typeIcon.setTextColor(Color.parseColor(groupColors["Promotions"] ?: "#F44336"))
                        }
                        else -> {
                            typeIcon.text = if (sms.type == 1) "📥" else "📤"
                            typeIcon.setTextColor(Color.LTGRAY)
                        }
                    }
                    
                    // Unread
                    if (!sms.read) {
                        senderText.setTypeface(senderText.typeface, Typeface.BOLD_ITALIC)
                    }
                }
            } catch (e: Exception) {
                Log.e("ADAPTER_ERROR", "Error: ${e.message}")
            }
            
            return view
        }
        
        override fun getCount(): Int = items.size
        
        override fun getItem(position: Int): SmsItem = items[position]
        
        override fun getItemId(position: Int): Long = position.toLong()
    }
}
