package com.iamrakeshpanchal.nimusms

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class ComposeActivity : AppCompatActivity() {
    
    private lateinit var recipientEdit: EditText
    private lateinit var messageEdit: EditText
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 20, 20, 20)
        }
        
        // Title
        val title = TextView(this).apply {
            text = "✉️ Compose Message"
            textSize = 20f
            setPadding(0, 0, 0, 20)
        }
        layout.addView(title)
        
        // Recipient
        val recipientLabel = TextView(this).apply {
            text = "To:"
            textSize = 16f
        }
        layout.addView(recipientLabel)
        
        recipientEdit = EditText(this).apply {
            hint = "Phone number"
            textSize = 18f
            setSingleLine(true)
        }
        layout.addView(recipientEdit)
        
        // Message
        val messageLabel = TextView(this).apply {
            text = "Message:"
            textSize = 16f
            setPadding(0, 20, 0, 0)
        }
        layout.addView(messageLabel)
        
        messageEdit = EditText(this).apply {
            hint = "Type your message..."
            textSize = 16f
            minLines = 4
        }
        layout.addView(messageEdit)
        
        // Buttons
        val buttonLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = 20 }
        }
        
        val sendBtn = Button(this).apply {
            text = "📤 Send"
            layoutParams = LinearLayout.LayoutParams(
                0,
                LinearLayout.LayoutParams.WRAP_CONTENT,
                1.0f
            ).apply { rightMargin = 10 }
            setOnClickListener { sendMessage() }
        }
        buttonLayout.addView(sendBtn)
        
        val cancelBtn = Button(this).apply {
            text = "Cancel"
            layoutParams = LinearLayout.LayoutParams(
                0,
                LinearLayout.LayoutParams.WRAP_CONTENT,
                1.0f
            )
            setOnClickListener { finish() }
        }
        buttonLayout.addView(cancelBtn)
        
        layout.addView(buttonLayout)
        
        setContentView(layout)
        
        // Check intent for pre-filled data
        handleIntent(intent)
    }
    
    private fun handleIntent(intent: Intent) {
        val data = intent.data
        if (data != null) {
            // Handle smsto:, sms:, mms:, mmsto: URIs
            val recipient = data.schemeSpecificPart
            if (recipient.contains(":")) {
                recipientEdit.setText(recipient.substringBefore(":"))
            } else {
                recipientEdit.setText(recipient)
            }
        }
        
        // Check for extra text
        val message = intent.getStringExtra("sms_body") ?: intent.getStringExtra(Intent.EXTRA_TEXT)
        if (!message.isNullOrEmpty()) {
            messageEdit.setText(message)
        }
    }
    
    private fun sendMessage() {
        val recipient = recipientEdit.text.toString().trim()
        val message = messageEdit.text.toString().trim()
        
        if (recipient.isEmpty()) {
            Toast.makeText(this, "Please enter recipient", Toast.LENGTH_SHORT).show()
            return
        }
        
        if (message.isEmpty()) {
            Toast.makeText(this, "Please enter message", Toast.LENGTH_SHORT).show()
            return
        }
        
        try {
            val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$recipient"))
            intent.putExtra("sms_body", message)
            startActivity(intent)
            Toast.makeText(this, "Sending message...", Toast.LENGTH_SHORT).show()
            finish()
        } catch (e: Exception) {
            Toast.makeText(this, "Error sending message", Toast.LENGTH_SHORT).show()
        }
    }
}
