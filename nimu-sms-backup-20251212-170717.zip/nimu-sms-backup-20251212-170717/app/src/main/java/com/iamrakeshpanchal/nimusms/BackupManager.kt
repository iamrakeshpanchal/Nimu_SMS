package com.iamrakeshpanchal.nimusms

import android.content.Context
import android.os.Environment
import android.util.Log
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileWriter
import java.text.SimpleDateFormat
import java.util.*

class BackupManager(private val context: Context) {
    
    data class BackupSms(
        val address: String,
        val body: String,
        val date: Long,
        val type: String,
        val read: Boolean
    )
    
    fun backupSMS(smsList: List<SmsListActivity.SmsItem>): Boolean {
        return try {
            val backupDir = File(context.getExternalFilesDir(null), "Backups")
            if (!backupDir.exists()) {
                backupDir.mkdirs()
            }
            
            val dateFormat = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault())
            val timestamp = dateFormat.format(Date())
            val backupFile = File(backupDir, "sms_backup_$timestamp.json")
            
            val jsonArray = JSONArray()
            for (sms in smsList) {
                val jsonSms = JSONObject().apply {
                    put("address", sms.address)
                    put("body", sms.body)
                    put("date", sms.date)
                    put("type", when(sms.type) {
                        1 -> "INBOX"
                        2 -> "SENT"
                        else -> "OTHER"
                    })
                    put("read", sms.read)
                    put("timestamp", System.currentTimeMillis())
                }
                jsonArray.put(jsonSms)
            }
            
            FileWriter(backupFile).use { writer ->
                writer.write(jsonArray.toString(2))
            }
            
            Toast.makeText(context, "Backup saved: ${backupFile.name}", Toast.LENGTH_LONG).show()
            Log.d("Backup", "Backup saved: ${backupFile.absolutePath}")
            true
        } catch (e: Exception) {
            Log.e("Backup", "Backup failed: ${e.message}")
            Toast.makeText(context, "Backup failed", Toast.LENGTH_SHORT).show()
            false
        }
    }
    
    fun getBackupFiles(): List<File> {
        val backupDir = File(context.getExternalFilesDir(null), "Backups")
        return if (backupDir.exists() && backupDir.isDirectory) {
            backupDir.listFiles()?.filter { it.name.endsWith(".json") }?.sortedByDescending { it.lastModified() } ?: emptyList()
        } else {
            emptyList()
        }
    }
    
    fun restoreBackup(backupFile: File): Boolean {
        return try {
            // Read backup file
            val jsonString = backupFile.readText()
            val jsonArray = JSONArray(jsonString)
            
            // For now just show stats
            Toast.makeText(context, "Backup contains ${jsonArray.length()} messages", Toast.LENGTH_LONG).show()
            Log.d("Restore", "Found ${jsonArray.length()} messages in backup")
            
            // Note: Actual restore to SMS database requires special permissions
            // This is just reading backup for now
            
            true
        } catch (e: Exception) {
            Log.e("Restore", "Restore failed: ${e.message}")
            Toast.makeText(context, "Restore failed", Toast.LENGTH_SHORT).show()
            false
        }
    }
}
