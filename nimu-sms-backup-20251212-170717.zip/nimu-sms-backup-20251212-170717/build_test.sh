#!/bin/bash
echo "Testing Gradle configuration..."
./gradlew projects
echo "---"
./gradlew tasks --group="build"
