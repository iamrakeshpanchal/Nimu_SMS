# Nimu SMS Changelog

## Current Working Features (v1.0)
- SMS loading from phone with permissions
- SMS list with preview
- SMS detail view on click
- Delete SMS with trash icon
- Send SMS in-app
- Bottom menu with Settings, Filter
- Search bar

## Features to Add:
1. Groups & Filters
2. OTP Handling
3. Message Bubble & Auto-Delete
4. Daily Backup to Google Drive
5. Daily Summary & Actionable Reminders
6. Promotional SMS Blocking
7. WhatsApp Icon for Contacts

## Update 2025-12-12 11:25:02
- Added feature framework without affecting current functionality
- Created database structure for groups and OTPs
- Added OTP detection utility
- Added WorkManager for auto-cleanup
- Added WhatsApp integration helper
- Added '✨ Features' button to access new features
